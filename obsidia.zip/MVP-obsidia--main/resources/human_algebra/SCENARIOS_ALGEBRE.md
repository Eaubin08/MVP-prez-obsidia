# Scénarios algébriques
Proof Mode (déterministe) / Live Mode (non-déterministe)
