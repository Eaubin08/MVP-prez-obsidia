# Table ALGEBRE ↔ PREUVES
Chaque loi correspond à un test X-108 / Gate validé.
