# Narration complète — Trade bloqué
Timeline T0→Tn, agents, lois activées, décision BLOCK.
