
X108 Ontology Tests v7 (DROP-IN)

Purpose:
Prove that the ontological constraints shown in the infographics
are necessary conditions of action, not architectural choices.
