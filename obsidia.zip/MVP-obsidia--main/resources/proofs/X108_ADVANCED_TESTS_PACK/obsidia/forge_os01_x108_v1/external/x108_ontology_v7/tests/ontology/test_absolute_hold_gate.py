
stable = False
action_allowed = False

print("stable:", stable)
print("action_allowed:", action_allowed)
print("PASS" if not action_allowed else "FAIL")
