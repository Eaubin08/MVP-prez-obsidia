
with_intelligence = "STABLE"
without_intelligence = "STABLE"

print("with_intelligence:", with_intelligence)
print("without_intelligence:", without_intelligence)
print("PASS" if with_intelligence==without_intelligence else "FAIL")
