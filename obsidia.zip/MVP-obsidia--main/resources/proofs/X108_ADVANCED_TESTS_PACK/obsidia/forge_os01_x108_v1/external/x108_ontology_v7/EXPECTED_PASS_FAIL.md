
All tests MUST PASS.
Any FAIL means a missing or invalid structural law.
