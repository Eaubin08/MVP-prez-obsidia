
attempts = ["decision_before_constance","intelligence_before_structure"]
blocked = True

print("Attempts:", attempts)
print("PASS" if blocked else "FAIL")
