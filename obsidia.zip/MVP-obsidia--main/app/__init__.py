"""Application Streamlit pour Obsidia Unified Interface."""
